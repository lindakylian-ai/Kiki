# StageKit — version iPhone (PWA)

StageKit est une maquette originale de boutique de simulateurs créatifs. Les interfaces sont des accessoires fictifs pour vidéos et démonstrations.

## Tester sur ordinateur
1. Décompresse le dossier.
2. Ouvre un terminal dans le dossier.
3. Lance `python3 -m http.server 8000`.
4. Ouvre `http://localhost:8000`.

## Installer sur iPhone
1. Héberge les fichiers sur un site HTTPS.
2. Ouvre l'URL dans Safari sur l'iPhone.
3. Appuie sur Partager.
4. Choisis « Sur l'écran d'accueil » puis « Ajouter ».

## Personnaliser
- Modifie le catalogue `apps` dans `index.html`.
- Ajuste les couleurs dans `:root` au début du CSS.
- Le bouton « Enregistrer la scène » conserve la personnalisation dans `localStorage` sur l'appareil.

## Notes
- Une PWA n'est pas une application native distribuée dans l'App Store.
- Le service worker met en cache les fichiers principaux.
- Les scènes sont des maquettes fictives, avec un libellé de simulation visible.
